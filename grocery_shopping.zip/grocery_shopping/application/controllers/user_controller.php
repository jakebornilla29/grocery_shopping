<?php
defined('BASEPATH') OR exit('No direct scripts access allowed');

class user_controller extends CI_Controller{

	public function index()
	{
		echo "Welcome User";
	}
}
