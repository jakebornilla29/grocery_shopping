<?php include_once 'header.php'; ?>
<h3>This is the Homepage</h3>


<a href="<?php echo base_url('login_controller/logout')  ?>" class="btn btn-warning">Logout</a>


<?php include_once 'footer.php';  ?>