<!DOCTYPE html>
<html>
<head>
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="<?php echo base_url('templates/css/bootstrap_login.min.css');?>">

<!-- jQuery library -->
<script src="<?php echo base_url('templates/css/jquery_login.min.js');?>"></script>

<!-- Latest compiled JavaScript -->
<script src="<?php echo base_url('templates/js/bootstrap_login.min.js')?>"></script>

	<link rel="stylesheet" type="text/css" href="<?php echo base_url('templates/css/login.css');?>">
</head>
<body>
